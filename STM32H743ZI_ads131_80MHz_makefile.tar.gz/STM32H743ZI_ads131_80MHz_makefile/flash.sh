sudo openocd -f STM32H743ZI_beta.cfg  -c "program build/STM32H743ZI_ads131_80MHz_makefile.elf verify reset exit"

